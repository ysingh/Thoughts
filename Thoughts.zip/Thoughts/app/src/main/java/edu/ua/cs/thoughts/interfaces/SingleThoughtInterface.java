package edu.ua.cs.thoughts.interfaces;

import edu.ua.cs.thoughts.entities.Thought;

/**
 * Created by vcaciuc on 11/7/2014.
 */
public interface SingleThoughtInterface {

    void launchThoughtFragment(Thought thought);

}
